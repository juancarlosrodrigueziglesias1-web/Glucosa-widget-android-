package com.example.glucowidget

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

data class Reading(val mgdl: Int, val trend: Int, val timestamp: Long)

object Store {
    private fun prefs(ctx: Context): SharedPreferences {
        val key = MasterKey.Builder(ctx).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
        return EncryptedSharedPreferences.create(
            ctx, "secure_prefs", key,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }

    fun saveCredentials(ctx: Context, email: String, password: String, mmol: Boolean) {
        prefs(ctx).edit().putString("email", email).putString("password", password)
            .putBoolean("mmol", mmol).apply()
    }

    fun email(ctx: Context) = prefs(ctx).getString("email", "") ?: ""
    fun password(ctx: Context) = prefs(ctx).getString("password", "") ?: ""
    fun mmol(ctx: Context) = prefs(ctx).getBoolean("mmol", false)

    fun saveReading(ctx: Context, r: Reading) {
        prefs(ctx).edit().putInt("mgdl", r.mgdl).putInt("trend", r.trend)
            .putLong("ts", r.timestamp).remove("error").apply()
    }

    fun saveError(ctx: Context, msg: String) {
        prefs(ctx).edit().putString("error", msg).apply()
    }

    fun reading(ctx: Context): Reading? {
        val p = prefs(ctx)
        if (!p.contains("mgdl")) return null
        return Reading(p.getInt("mgdl", 0), p.getInt("trend", 3), p.getLong("ts", 0))
    }

    fun error(ctx: Context): String? = prefs(ctx).getString("error", null)
}
