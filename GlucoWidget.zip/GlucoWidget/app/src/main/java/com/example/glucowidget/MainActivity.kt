package com.example.glucowidget

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { Screen() } }
    }

    @Composable
    private fun Screen() {
        var email by remember { mutableStateOf(Store.email(this)) }
        var pass by remember { mutableStateOf(Store.password(this)) }
        var mmol by remember { mutableStateOf(Store.mmol(this)) }
        var saved by remember { mutableStateOf(false) }

        Column(
            Modifier.fillMaxSize().systemBarsPadding().padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("Gluco Widget", style = MaterialTheme.typography.headlineMedium)
            Text(
                "1) En LibreLink: Menú > Conectado > LibreLinkUp, y envía una invitación.\n" +
                "2) Instala LibreLinkUp, crea la cuenta con ese email y acepta.\n" +
                "3) Pon aquí los datos de esa cuenta LibreLinkUp.\n" +
                "4) Añade el widget desde la pantalla de inicio.\n\n" +
                "Solo para consulta. No uses este widget para decidir dosis de insulina."
            )
            OutlinedTextField(email, { email = it; saved = false }, label = { Text("Email LibreLinkUp") },
                singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(pass, { pass = it; saved = false }, label = { Text("Contraseña") },
                singleLine = true, visualTransformation = PasswordVisualTransformation(),
                modifier = Modifier.fillMaxWidth())
            Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                Switch(mmol, { mmol = it; saved = false })
                Spacer(Modifier.width(8.dp))
                Text(if (mmol) "mmol/L" else "mg/dL")
            }
            Button(onClick = {
                Store.saveCredentials(this@MainActivity, email.trim(), pass, mmol)
                RefreshWorker.schedule(this@MainActivity)
                RefreshWorker.refreshNow(this@MainActivity)
                saved = true
            }) { Text("Guardar y actualizar") }
            if (saved) Text("Guardado. El widget se actualizará en unos segundos.")
        }
    }
}
