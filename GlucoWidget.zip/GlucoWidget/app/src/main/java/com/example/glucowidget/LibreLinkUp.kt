package com.example.glucowidget

import org.json.JSONObject
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone

/**
 * Cliente NO oficial de LibreLinkUp. Puede dejar de funcionar si Abbott cambia la API.
 * Si falla con error de version, sube APP_VERSION.
 */
object LibreLinkUp {
    private const val APP_VERSION = "4.12.0"

    fun fetch(email: String, password: String): Reading {
        var base = "https://api.libreview.io"
        val body = JSONObject().put("email", email).put("password", password).toString()

        var login = call("POST", "$base/llu/auth/login", body, null, null)
        if (login.optJSONObject("data")?.optBoolean("redirect") == true) {
            val region = login.getJSONObject("data").getString("region")
            base = "https://api-$region.libreview.io"
            login = call("POST", "$base/llu/auth/login", body, null, null)
        }
        when (login.optInt("status")) {
            0 -> {}
            2 -> error("Email o contraseña incorrectos")
            4 -> error("Abre LibreLinkUp en el móvil y acepta los términos")
            else -> error("Login falló (status ${login.optInt("status")})")
        }
        val data = login.getJSONObject("data")
        val token = data.getJSONObject("authTicket").getString("token")
        val userId = data.getJSONObject("user").getString("id")
        val accountId = MessageDigest.getInstance("SHA-256").digest(userId.toByteArray())
            .joinToString("") { "%02x".format(it) }

        val conns = call("GET", "$base/llu/connections", null, token, accountId)
            .optJSONArray("data")
        if (conns == null || conns.length() == 0)
            error("No hay conexiones. Comparte tus datos desde LibreLink hacia LibreLinkUp")

        val gm = conns.getJSONObject(0).getJSONObject("glucoseMeasurement")
        val mgdl = Math.round(gm.getDouble("ValueInMgPerDl")).toInt()
        val trend = gm.optInt("TrendArrow", 3)
        val fmt = SimpleDateFormat("M/d/yyyy h:mm:ss a", Locale.US)
        fmt.timeZone = TimeZone.getTimeZone("UTC")
        val ts = fmt.parse(gm.getString("FactoryTimestamp"))?.time ?: System.currentTimeMillis()
        return Reading(mgdl, trend, ts)
    }

    private fun call(
        method: String, url: String, body: String?, token: String?, accountId: String?
    ): JSONObject {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = method
        c.connectTimeout = 15000
        c.readTimeout = 15000
        c.setRequestProperty("Content-Type", "application/json")
        c.setRequestProperty("Accept", "application/json")
        c.setRequestProperty("product", "llu.android")
        c.setRequestProperty("version", APP_VERSION)
        if (token != null) c.setRequestProperty("Authorization", "Bearer $token")
        if (accountId != null) c.setRequestProperty("Account-Id", accountId)
        if (body != null) {
            c.doOutput = true
            OutputStreamWriter(c.outputStream).use { it.write(body) }
        }
        val stream = if (c.responseCode in 200..299) c.inputStream else c.errorStream
        val text = stream?.bufferedReader()?.use { it.readText() } ?: "{}"
        return JSONObject(text)
    }
}
