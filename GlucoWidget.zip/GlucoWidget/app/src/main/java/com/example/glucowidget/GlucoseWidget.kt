package com.example.glucowidget

import android.content.Context
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.glance.GlanceId
import androidx.glance.GlanceModifier
import androidx.glance.action.ActionParameters
import androidx.glance.action.clickable
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.GlanceAppWidgetReceiver
import androidx.glance.appwidget.action.ActionCallback
import androidx.glance.appwidget.action.actionRunCallback
import androidx.glance.appwidget.cornerRadius
import androidx.glance.appwidget.provideContent
import androidx.glance.background
import androidx.glance.layout.*
import androidx.glance.text.FontWeight
import androidx.glance.text.Text
import androidx.glance.text.TextStyle
import androidx.glance.unit.ColorProvider

class GlucoseWidget : GlanceAppWidget() {
    override suspend fun provideGlance(context: Context, id: GlanceId) {
        val reading = Store.reading(context)
        val error = Store.error(context)
        val mmol = Store.mmol(context)
        provideContent { Content(reading, error, mmol) }
    }
}

@Composable
private fun Content(r: Reading?, error: String?, mmol: Boolean) {
    val bg = when {
        r == null -> Color(0xFF455A64)
        r.mgdl < 70 -> Color(0xFFC62828)
        r.mgdl > 180 -> Color(0xFFEF6C00)
        else -> Color(0xFF2E7D32)
    }
    Box(
        modifier = GlanceModifier.fillMaxSize()
            .background(ColorProvider(bg)).cornerRadius(20.dp)
            .clickable(actionRunCallback<RefreshAction>()),
        contentAlignment = Alignment.Center
    ) {
        if (r == null) {
            Text(
                error ?: "Configura la app",
                style = TextStyle(color = ColorProvider(Color.White), fontSize = 12.sp)
            )
        } else {
            val value = if (mmol) "%.1f".format(r.mgdl / 18.0182) else r.mgdl.toString()
            val mins = ((System.currentTimeMillis() - r.timestamp) / 60000).coerceAtLeast(0)
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    "$value ${arrow(r.trend)}",
                    style = TextStyle(
                        color = ColorProvider(Color.White),
                        fontSize = 30.sp, fontWeight = FontWeight.Bold
                    )
                )
                Text(
                    (if (mmol) "mmol/L" else "mg/dL") + " · hace $mins min",
                    style = TextStyle(color = ColorProvider(Color.White), fontSize = 11.sp)
                )
            }
        }
    }
}

private fun arrow(t: Int) = when (t) {
    1 -> "↓↓"; 2 -> "↓"; 3 -> "→"; 4 -> "↑"; 5 -> "↑↑"; else -> ""
}

class RefreshAction : ActionCallback {
    override suspend fun onAction(context: Context, glanceId: GlanceId, parameters: ActionParameters) {
        RefreshWorker.refreshNow(context)
    }
}

class GlucoseWidgetReceiver : GlanceAppWidgetReceiver() {
    override val glanceAppWidget: GlanceAppWidget = GlucoseWidget()

    override fun onEnabled(context: Context) {
        super.onEnabled(context)
        RefreshWorker.schedule(context)
        RefreshWorker.refreshNow(context)
    }
}
