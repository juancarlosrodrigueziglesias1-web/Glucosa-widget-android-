package com.example.glucowidget

import android.content.Context
import androidx.glance.appwidget.updateAll
import androidx.work.*
import java.util.concurrent.TimeUnit

class RefreshWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        val ctx = applicationContext
        val email = Store.email(ctx)
        if (email.isNotBlank()) {
            try {
                Store.saveReading(ctx, LibreLinkUp.fetch(email, Store.password(ctx)))
            } catch (e: Exception) {
                Store.saveError(ctx, e.message ?: "Error de red")
            }
        }
        GlucoseWidget().updateAll(ctx)
        return Result.success()
    }

    companion object {
        private val net = Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()

        fun schedule(ctx: Context) {
            val req = PeriodicWorkRequestBuilder<RefreshWorker>(15, TimeUnit.MINUTES)
                .setConstraints(net).build()
            WorkManager.getInstance(ctx)
                .enqueueUniquePeriodicWork("glucose_periodic", ExistingPeriodicWorkPolicy.KEEP, req)
        }

        fun refreshNow(ctx: Context) {
            WorkManager.getInstance(ctx).enqueue(
                OneTimeWorkRequestBuilder<RefreshWorker>().setConstraints(net).build()
            )
        }
    }
}
